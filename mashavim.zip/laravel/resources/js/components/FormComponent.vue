
<template>
    <form class="text-center w-50 mx-auto mt-5">        
        <div class="form-group">
            <label for="name">:שם מלא</label>
            <input type='text' class="form-control " v-model='form.name' id="name" />
            <span class="text-danger" v-if="errors.name" v-text="errors.name"></span>
        </div>
         <div class="form-group">
             <label for="phone">:טלפון</label>
            <input type='tel' class="form-control" v-model='form.phone' id="phone"/>
             <span class="text-danger"  v-if="errors.phone" v-text="errors.phone"></span>
        </div>
          <div class="form-group">
              <label for="email">:אימייל</label>
            <input type='email' class="form-control" v-model='form.email' id="email" />
            <span class="text-danger"  v-if="errors.email" v-text="errors.email" ></span>
        </div>
          <div class="form-group">
              <label for="id">:תעודת זהות</label>
            <input type='tel' class="form-control" v-model='form.id' id="id"/>
            <span class="text-danger"  v-if="errors.id" v-text="errors.id" ></span>
        </div>
        
        <hr>

        <button @click.prevent='submit' class="btn btn-primary">
            Send
        </button>
        <div class="mt-5" v-if="status" v-text="status"></div>
    </form>
</template>

<script>
import validator from "validator";


  export default {
    data: () => ({
        form:{
            name: '',
            phone: '',
            email: '',
            id: '', 
        },
        errors:{
            name:"",
            phone:"",
            email:"",
            id:""
        },
        premiaSum:0,
        status:"",
        
        
   }),

    methods: {
    submit() {
          this.errors = {};

          if(this.formValidator(this.form)) { 

              this.formToApi();

          }          
         },
        formValidator(form){
            let valid = true;
            let nameRegExp =  /^[a-z\u0590-\u05fe\s]+$/i;

          (!nameRegExp.test(form.name) && (this.errors.name="נא להזין אותיות בלבד"));      
          (!validator.isMobilePhone(form.phone,"he-IL") &&  (this.errors.phone="נא להזין מס' ישראלי בלבד"));       
          (!validator.isEmail(form.email) && (this.errors.email="האימייל שהוזן אינו תקין"));    
          (!this.is_israeli_id_number(form.id) && (this.errors.id="נא להזין תעודת זהות ישראלית בלבד"));
          
          if(Object.keys(this.errors).length > 0) valid = false;

          return valid;

        },

        is_israeli_id_number(id) {
	        id = String(id).trim();
	        if (!id || id.length > 9 || isNaN(id)) return false;
	            id = id.length < 9 ? ("00000000" + id).slice(-9) : id;
		        return Array.from(id, Number).reduce((counter, digit, i) => {
			const step = digit * ((i % 2) + 1);
			return counter + (step > 9 ? step - 9 : step);
		    }) % 10 === 0;
        },

       formToApi(){
           
            axios.post('https://ibell.frb.io/api/test/getJson',
            {
                שם_מלא:this.form.name,
                טלפון:this.form.phone,
                אימייל:this.form.email,
                תעודת_זהות:this.form.id
                
            }).then((response)=>{

                if(response.data.status=="success"){
                        
                    for(const values in response.data.hbJson){
                                               
                      let resp = response.data.hbJson[values];
                      
                        for(const prem of resp){
                            
                           prem["premia"]>0 ? this.premiaSum += Number(prem["premia"]): false;
                            
                        }
                  
                    }
                    
                    let endpoint = this.premiaSum>50?
                     "https://ibell.frb.io/zapier/add/lead/31198":"https://ibell.frb.io/zapier/add/lead/38754";

                    this.savePremia(endpoint)
                    this.premiaSum = 0;

                }else if(response.data.status=="failure"){

                   
                    this.status = response.data.errmsg;

                }
            }).catch(error =>{
                console.log(error)})
         },
        
        savePremia(endpoint){

            axios.post(endpoint,
            {
                שם_מלא:this.form.name,
                טלפון:this.form.phone,
                אימייל:this.form.email,
                תעודת_זהות:this.form.id

            }).then((response)=>{
                
            this.status = response.status === 200 ? "saved successfully" : "something went wrong";
           
            })
        
        }
         
    }
}














function is_israeli_id_number(id) {
	id = String(id).trim();
	if (id.length > 9 || isNaN(id)) return false;
	id = id.length < 9 ? ("00000000" + id).slice(-9) : id;
		return Array.from(id, Number).reduce((counter, digit, i) => {
			const step = digit * ((i % 2) + 1);
			return counter + (step > 9 ? step - 9 : step);
		}) % 10 === 0;
}


</script>
 